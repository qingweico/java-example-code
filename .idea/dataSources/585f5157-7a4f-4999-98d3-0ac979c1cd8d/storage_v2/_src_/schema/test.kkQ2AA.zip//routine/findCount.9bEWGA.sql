create
    definer = root@`%` function findCount() returns int
BEGIN
    DECLARE counts int default 0; 
    SELECT count(*) INTO counts
    from student;
    return countS;
END;

