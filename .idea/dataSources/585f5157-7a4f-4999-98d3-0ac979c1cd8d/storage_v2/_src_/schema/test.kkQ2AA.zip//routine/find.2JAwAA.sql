create
    definer = root@localhost procedure find()
BEGIN
   select * from student;
END;

