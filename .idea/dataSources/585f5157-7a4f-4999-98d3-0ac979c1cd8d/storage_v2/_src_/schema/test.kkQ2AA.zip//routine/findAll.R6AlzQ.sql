create
    definer = root@localhost procedure findAll()
BEGIN
    select * from student;
END;

