create
    definer = root@localhost procedure resultToName(IN id int, OUT name varchar(10))
BEGIN
    select student.name INTO `name` from student WHERE student.id = id;
END;

