create
    definer = root@`%` procedure score(IN score int)
BEGIN
    CASE
    WHEN score>=90 AND score <=100 THEN SELECT '优' 等级;
    WHEN score>=80 THEN SELECT '好' 等级;
    WHEN score>=70 THEN SELECT '良' 等级;
    WHEN score>=60 THEN SELECT '及格' 等级;
    ELSE SELECT '不及格' 等级;
    END CASE;
END;

