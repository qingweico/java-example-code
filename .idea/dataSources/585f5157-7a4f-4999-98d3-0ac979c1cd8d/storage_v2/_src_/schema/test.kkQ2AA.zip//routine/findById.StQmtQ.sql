create
    definer = root@localhost procedure findById(IN id int)
BEGIN
       select * from student where student.id =  id;

END;

