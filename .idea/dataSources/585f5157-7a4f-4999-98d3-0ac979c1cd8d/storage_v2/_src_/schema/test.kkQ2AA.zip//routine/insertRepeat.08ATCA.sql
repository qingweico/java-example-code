create
    definer = root@`%` procedure insertRepeat(IN count int)
BEGIN
     set @i = 0;
     REPEAT
     INSERT into account(username,password) values(concat('用户',@i),@i);
     UNTIL @i = count 
     END REPEAT;
end;

