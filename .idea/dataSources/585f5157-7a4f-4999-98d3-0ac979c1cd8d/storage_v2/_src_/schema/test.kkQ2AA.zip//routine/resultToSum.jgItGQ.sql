create
    definer = root@`%` function resultToSum(a double, b double) returns double
BEGIN
     set @sum = a+b;
     return @sum;
END;

