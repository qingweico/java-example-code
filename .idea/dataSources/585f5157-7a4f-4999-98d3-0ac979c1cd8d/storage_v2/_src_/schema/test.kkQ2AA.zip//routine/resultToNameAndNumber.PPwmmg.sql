create
    definer = root@localhost procedure resultToNameAndNumber(IN id int, OUT name varchar(10), OUT number varchar(10))
BEGIN
    select student.name,student.number INTO `name`,number from student WHERE student.id = id;
END;

