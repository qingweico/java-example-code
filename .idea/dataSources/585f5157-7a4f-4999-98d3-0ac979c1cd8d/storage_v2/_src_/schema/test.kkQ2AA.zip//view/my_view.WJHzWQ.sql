create view my_view as
select `test`.`job`.`name` AS `name`, `test`.`job`.`salary` AS `salary`
from `test`.`job`;

