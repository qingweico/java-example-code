create
    definer = root@`%` procedure loopOfTimes(IN number int)
BEGIN
      declare i int DEFAULT 1;
      loops:LOOP
      insert into account(username,password) values(CONCAT('用户',i),i);
      if i = number then leave loops;
      end if;
      set i = i + 1;
end loop loops;
END;

