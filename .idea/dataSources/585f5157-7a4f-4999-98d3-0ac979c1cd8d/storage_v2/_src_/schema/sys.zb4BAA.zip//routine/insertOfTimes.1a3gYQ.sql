create
    definer = root@`%` procedure insertOfTimes(IN count int)
BEGIN
     set @i := 1;
     #declare i int DEFAULT 1; 
     repeat
     insert into account(username,password) values(concat('用户',@i),@i);
     set @i := @i +1;
     UNTIL @i = count
END REPEAT;
END;

