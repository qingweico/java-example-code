create
    definer = root@localhost procedure findClass(IN name varchar(10), OUT result varchar(20))
BEGIN 
        select CONCAT(`name`,' and ',IFNULL(cname,'无班级')) INTO result
         from student left JOIN class on student.number = class.cid 
          where student.name = name;
END;

